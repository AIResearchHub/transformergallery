# Self-Attention

Toy Programs to understand multi-head attention and self attention by consequence.

To be added to larger transformer gallery.
